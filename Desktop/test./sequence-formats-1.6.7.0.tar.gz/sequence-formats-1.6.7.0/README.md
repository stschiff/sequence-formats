Sequence-Formats is a Haskell package to provide file parsers and writers for some commonly, and less commonly used file formats in Bioinformatics, speficially population genetics.

The library makes heavy use of the [pipes library](http://hackage.haskell.org/package/pipes) to provide Producers and Consumers for reading and writing files.
